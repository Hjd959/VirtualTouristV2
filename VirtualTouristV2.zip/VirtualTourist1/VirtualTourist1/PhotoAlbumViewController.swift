//
//  PhotoAlbumViewController.swift
//  VirtualTourist1
//
//  Created by عبدالوهاب العنزي on 20/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var albumCollection: UICollectionView!
    @IBOutlet weak var getNewCollectionButton: UIButton!

    private let itemsPerRow: CGFloat = 3
    private let insets = UIEdgeInsets(top: 10.0, left: 10.0, bottom: 10.0, right: 10.0)

    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<Photo>!
    var pin: Pin!

    //  Life cycle Methods

    override func viewDidLoad() {
        super.viewDidLoad()

        albumCollection.dataSource = self
        albumCollection.delegate = self

        setupFetchedResultsController()

        enableGetNewCollectionButton(enable: false)

        if (fetchedResultsController.sections?[0].numberOfObjects ?? 0 == 0) {
            getPhotos()
        } else {
            enableGetNewCollectionButton(enable: true)
        }

        mapView.addAnnotation(pin)
        mapView.showAnnotations([pin], animated: true)
        mapView.isUserInteractionEnabled = false
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        setupFetchedResultsController()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        fetchedResultsController = nil
    }
}

//  Private Methods

extension PhotoAlbumViewController: NSFetchedResultsControllerDelegate {

    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            albumCollection.insertItems(at: [newIndexPath!])
            break
        case .delete:
            albumCollection.deleteItems(at: [indexPath!])
            break
        default: ()
        }
    }

    private func setupFetchedResultsController() {
        let fetchRequest: NSFetchRequest<Photo> = Photo.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
        let predicate = NSPredicate(format: "pin == %@", pin)

        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchRequest.predicate = predicate

        fetchedResultsController = NSFetchedResultsController(
            fetchRequest: fetchRequest,
            managedObjectContext: dataController.viewContext,
            sectionNameKeyPath: nil,
            cacheName: nil)
        fetchedResultsController.delegate = self

        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }

    private func enableGetNewCollectionButton(enable: Bool) {
        self.getNewCollectionButton.isEnabled = enable
    }

     func getPhotos() {
        enableGetNewCollectionButton(enable: false)

        FlickrClient.getPhotos(lat: pin.latitude, long: pin.longitude) { photoURLlist, error in
        
            if let error = error {
                self.showError(withMessage: error.localizedDescription)

                return
            }

            if let photoURLlist = photoURLlist {
                for url in photoURLlist {
                    self.addPhoto(url: url)
                }
            }

            DispatchQueue.main.async {
                self.albumCollection.reloadData()
                self.enableGetNewCollectionButton(enable: true)
            }
        }
    }

//    let flickrCall = FlickrApi.sharedInstance
//
//    flickrCall.getPhotosforLocation(pin.latitude, pin.longtiute, 20) { (success, photos) in
//
//    if success == false {
//    print("Unable to download images from Flickr.")
//    return
//    }
//
//    print("Flickr images fetched : \(photos!.count)")
//    if photos!.count == 0 {
//    // show this message when No image to download.
//    Alert.Alert(message: "No image in this location", title: ":)", vc: self)
//    }
//
//
//    photos!.forEach() { photo_url in
//    let photo = Photos(context: self.dataController.viewContext)
//    photo.photoURL = URL(string: photo_url["url_m"] as! String)?.absoluteString
//    photo.pin = self.pin
//
//    do {
//    // Saves to CoreData
//    try self.dataController.viewContext.save()
//    } catch  {
//    print(error.localizedDescription)
//    print("Flickr images fetched : \(photos!.count)")
//    }
//    }
//    }
//}

    private func addPhoto(url: String) {
        let photo = Photo(context: dataController.viewContext)

        photo.creationDate = Date()
        photo.url = url
        photo.pin = pin

               try? dataController.viewContext.save()
    }

    private func deletePhoto(_ photo: Photo) {
        dataController.viewContext.delete(photo)

        do {
            try dataController.viewContext.save()
        } catch {
            print("Error saving")
        }
    }

  //  Download Images
    
    func downloadImage( imagePath:String, completionHandler: @escaping (_ imageData: Data?, _ errorString: String?) -> Void){
        
        // Create session and request
        let session = URLSession.shared
        let imgURL = NSURL(string: imagePath)
        let request: NSURLRequest = NSURLRequest(url: imgURL! as URL)
        
        // Create network request
        let task = session.dataTask(with: request as URLRequest) {data, response, downloadError in
            
            if downloadError != nil {
                completionHandler(nil, "Could not download image \(imagePath)")
            } else {
                
                completionHandler(data, nil)
            }
        }
        task.resume()
    }
    
    @IBAction func deleteAllPhotos() {
        if let photos = fetchedResultsController.fetchedObjects {
            for photo in photos {
                dataController.viewContext.delete(photo)

                do {
                    try dataController.viewContext.save()
                } catch {
                    print("Unable to save to the db")
                }
            }
        }
        getPhotos()
        
    }
}

//  CollectionView Datasource

extension PhotoAlbumViewController: UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        /*
         I wasn't able to find a better way to handle 'if no photos are found for a location'.
         The message will pop-up for every location, but as soon as the placeholders and images start
         popping up, this message will go away.

         If the location doesn't have any photo, then this message will remain displayed.

         I tried stackoverflow, and this seem to be the best solution.
         */
        if (fetchedResultsController.sections?[section].numberOfObjects ?? 0 == 0) {
            albumCollection.setEmptyMessage("No photos found for this location.")
        } else {
            albumCollection.deleteEmptyMessage()
        }

        return fetchedResultsController.sections?[section].numberOfObjects ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let photoData = fetchedResultsController.object(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCollectionViewCell

        cell.imageView.image = UIImage(named: "placeholder")

        if let photoData = photoData.data {
            cell.imageView.image = UIImage(data: photoData)

        } else if let photoUrl = photoData.url {
            guard let url = URL(string: photoUrl) else {
                fatalError("Not valid URL for photo.")
            }

            FlickrClient.getPhotoImage(url: url) { data, error in
                if let error = error {
                    self.showError(withMessage: error.localizedDescription)

                    return
                }

                if let data = data {
                    cell.imageView.image = UIImage(data: data)
                } else {
                    self.showError(withMessage: "No image found.")
                }
                photoData.data = data
                try? self.dataController.viewContext.save()
            }
        }

        return cell
    }
}

//  CollectionView FlowLayout

extension PhotoAlbumViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath)
        -> CGSize {
            let padding = insets.right * (itemsPerRow + 1)
            let availableWidth = view.frame.width - padding
            let widthOfItem = availableWidth / itemsPerRow

            return CGSize(width: widthOfItem, height: widthOfItem)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int)
        -> UIEdgeInsets {
            return insets
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return insets.right
    }
}

//  CollectionView Delegate

extension PhotoAlbumViewController: UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photoToDelete = fetchedResultsController.object(at: indexPath)
        deletePhoto(photoToDelete)
    }
}

