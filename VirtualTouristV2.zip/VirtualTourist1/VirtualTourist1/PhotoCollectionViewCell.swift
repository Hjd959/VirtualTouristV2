//
//  PhotoCollectionViewCell.swift
//  VirtualTourist1
//
//  Created by عبدالوهاب العنزي on 20/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
