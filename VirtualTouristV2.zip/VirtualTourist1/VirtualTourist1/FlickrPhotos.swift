//
//  FlickrPhotos.swift
//  VirtualTourist1
//
//  Created by عبدالوهاب العنزي on 20/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import Foundation

struct FlickrPhotos: Codable {
    
    let page: Int
    let pages: Int
    let perpage: Int
    let total: String
    let photo: [FlickrPhoto]
    
    enum CodingKeys: String, CodingKey {
        case page
        case pages
        case perpage
        case total
        case photo
    }
}
