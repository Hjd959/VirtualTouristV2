//
//  ViewController+Extension.swift
//  VirtualTourist1
//
//  Created by عبدالوهاب العنزي on 20/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import UIKit

extension UIViewController {
    
    // function Show error
    
    func showError(withTitle: String = "Error", withMessage: String, action: (() -> Void)? = nil) {
        performUIUpdatesOnMain {
            
            // alert view
            
            let ac = UIAlertController(title: withTitle, message: withMessage, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: {(alertAction) in
                action?()
            }))
            self.present(ac, animated: true)
        }
    }
    
    func performUIUpdatesOnMain(_ updates: @escaping () -> Void) {
        DispatchQueue.main.async {
            updates()
        }
    }
}

