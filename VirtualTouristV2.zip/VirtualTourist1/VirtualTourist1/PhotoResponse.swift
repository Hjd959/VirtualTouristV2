//
//  PhotoResponse.swift
//  VirtualTourist1
//
//  Created by عبدالوهاب العنزي on 20/10/1440 AH.
//  Copyright © 1440 Abdulwahab. All rights reserved.
//

import Foundation

struct PhotoResponse: Codable {
    let photos: FlickrPhotos
    let stat: String
    
    enum CodingKeys: String, CodingKey {
        case photos
        case stat
    }
}

